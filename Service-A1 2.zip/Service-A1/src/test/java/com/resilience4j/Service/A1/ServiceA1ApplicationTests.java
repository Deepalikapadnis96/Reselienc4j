package com.resilience4j.Service.A1;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ServiceA1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
